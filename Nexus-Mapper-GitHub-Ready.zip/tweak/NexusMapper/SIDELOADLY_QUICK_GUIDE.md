# ⚡ Sideloadly Quick Guide - Nexus Mapper

## 🎯 Objetivo
Instalar Nexus Mapper no iPhone em 5 minutos usando Sideloadly.

## 📋 Pré-requisitos

- ✅ Mac com Xcode
- ✅ iPhone com iOS 14+
- ✅ Sideloadly instalado ([Download](https://sideloadly.io/))
- ✅ Arquivo `.ipa` compilado

## 🚀 Passo 1: Compilar o .ipa (30 minutos)

### Via Terminal (Automático)

```bash
cd /path/to/NexusMapper
chmod +x build-ipa.sh
./build-ipa.sh
```

Aguarde a compilação. O arquivo `.ipa` estará em:
```
build/Export/NexusMapper.ipa
```

### Via Xcode (Manual)

1. Abra o projeto no Xcode
2. Product → Archive
3. Clique em "Distribute App"
4. Selecione "Ad Hoc"
5. Clique em "Export"
6. Salve como `NexusMapper.ipa`

## 📱 Passo 2: Instalar via Sideloadly (5 minutos)

### 2.1 Preparar iPhone

1. Conecte o iPhone ao Mac via USB
2. Desbloqueie o iPhone
3. Toque em "Trust" se solicitado

### 2.2 Abrir Sideloadly

1. Abra **Sideloadly** no Mac
2. O iPhone deve aparecer automaticamente

### 2.3 Selecionar IPA

1. Clique em "Select IPA"
2. Procure por `NexusMapper.ipa`
3. Selecione

### 2.4 Instalar

1. Clique em "Start"
2. Aguarde a instalação (2-3 minutos)
3. Clique em "Trust" no iPhone se solicitado

### 2.5 Pronto!

O app "Nexus Mapper" deve aparecer na Home Screen.

## ✅ Testar

1. **Abra o app** "Nexus Mapper" no iPhone
2. Você verá uma tela com "✅ Tweak Ativo"
3. Clique em "Testar Painel" para ver o overlay
4. **Abra um jogo** (Free Fire, PUBG, etc.)
5. Procure pelo botão **"N"** flutuante no canto
6. Toque para abrir o painel de configuração

## 🎮 Usar no Jogo

1. Abra Free Fire ou outro jogo
2. Procure pelo botão "N" no canto da tela
3. Toque para abrir o painel
4. Ajuste:
   - **Sensibilidade X/Y**: Mova os sliders
   - **Perfil**: Selecione Free Fire, PUBG, etc.
   - **Mostrar Botões**: Ative/desative o switch
5. Clique "Salvar e Fechar"

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| iPhone não aparece em Sideloadly | Reconectar USB, reiniciar Sideloadly |
| "Provisioning Profile Error" | Ir para Xcode → Preferences → Accounts → Download Profiles |
| App não instala | Tentar novamente, ou usar "Resign & Install" |
| Botão "N" não aparece no jogo | Abrir o app Nexus Mapper primeiro para inicializar |
| App fecha ao abrir | Verificar Console (Xcode → Devices and Simulators) |

## 📝 Notas Importantes

- O app é válido por **7 dias** (com certificado de desenvolvimento)
- Você precisa reconectar ao Mac a cada 7 dias para renovar
- Sideloadly requer que o iPhone esteja conectado via USB
- O app não funciona em jogos que detectam injeção (alguns jogos anti-cheat)

## 🎯 Próximos Passos

1. ✅ Compilar .ipa
2. ✅ Instalar via Sideloadly
3. ✅ Testar em Free Fire
4. 🔄 Ajustar sensibilidade para seu estilo
5. 🔄 Usar em outros jogos

## 📚 Referências

- [Sideloadly Website](https://sideloadly.io/)
- [Xcode Documentation](https://developer.apple.com/xcode/)
- [iOS App Distribution](https://developer.apple.com/distribute/)

---

**Tempo total: 35 minutos** ⏱️

**Desenvolvido com ❤️ para iOS**
