# ⚡ Quick Start - Nexus Mapper Tweak

## 🎯 Objetivo
Compilar o Tweak e testar no seu iPhone em 15 minutos.

## 📋 Checklist Rápido

- [ ] Você tem um Mac com Xcode?
- [ ] Você tem um iPhone com Jailbreak/TrollStore?
- [ ] Você tem os 3 arquivos Swift?

## 🚀 Passo 1: Preparar no Mac

### 1.1 Copiar Arquivos

Copie estes 3 arquivos para uma pasta no Mac:

```
NexusMapper/
├── OverlayMenuManager.swift
├── TouchInjectionController.swift
└── NexusMapperHook.swift
```

### 1.2 Abrir no Xcode

1. Abra o **Xcode**
2. File → New → Project
3. Selecione **Framework** (iOS)
4. Nome: `NexusMapper`
5. Language: `Swift`
6. Clique em **Create**

### 1.3 Adicionar Arquivos

1. Arraste os 3 arquivos `.swift` para o projeto
2. Certifique-se de que estão no target `NexusMapper`

## 🔨 Passo 2: Compilar

### 2.1 Configurar Build

1. Selecione o target `NexusMapper`
2. Build Settings
3. Procure por `Mach-O Type` e mude para `Dynamic Library`
4. Procure por `Architectures` e selecione `arm64`

### 2.2 Compilar

```bash
# Via Terminal
xcodebuild -scheme NexusMapper -configuration Release -arch arm64 -sdk iphoneos
```

Ou simplesmente:
- Product → Build (Cmd + B)

## 📦 Passo 3: Encontrar o Dylib

Após compilar:

1. Product → Show Build Folder in Finder
2. Navegue até: `Release-iphoneos/`
3. Procure por `libNexusMapper.dylib`
4. **Copie este arquivo**

## 📱 Passo 4: Instalar no iPhone

### Opção A: Via TrollStore (Mais Fácil)

1. Abra o **TrollStore** no iPhone
2. Selecione um app (ex: Free Fire)
3. Clique em "Inject"
4. Selecione `libNexusMapper.dylib`
5. Clique em "Inject"

### Opção B: Via Theos (Jailbreak)

```bash
# No Mac
theos new:tweak NexusMapper
cd $THEOS/projects/NexusMapper

# Copiar arquivos Swift
cp /path/to/*.swift NexusMapper/

# Compilar e instalar
make package
make install THEOS_DEVICE_IP=seu.iphone.ip
```

### Opção C: Via Xcode (Debugging)

1. Conecte o iPhone
2. Xcode → Product → Run
3. Selecione o app alvo
4. Xcode vai injetar automaticamente

## ✅ Testar

1. Abra um jogo no iPhone (Free Fire, PUBG, etc.)
2. Procure por um botão **"N"** flutuante no canto da tela
3. Toque no botão "N"
4. O painel de configuração deve abrir
5. Ajuste sensibilidade, perfil, etc.
6. Clique "Salvar e Fechar"

## 🎮 Se Funcionar

Parabéns! 🎉

O Tweak está rodando. Agora você pode:
- Ajustar sensibilidade do joystick
- Mudar perfis de jogo
- Ativar/desativar botões na tela
- Usar macros

## 🐛 Se Não Funcionar

### Botão "N" não aparece

1. Verificar se o dylib foi injetado corretamente
2. Abrir Console (Xcode → Window → Devices and Simulators)
3. Procurar por logs: `[NexusMapper]`

### Erro de compilação

1. Verificar se está usando Xcode (não terminal Linux)
2. Verificar se UIKit está disponível
3. Verificar se o target é iOS, não macOS

### Painel não abre

1. Verificar se `initialize()` foi chamado
2. Verificar se o tap gesture está funcionando
3. Verificar logs no Console

## 📚 Documentação Completa

- **BUILD_INSTRUCTIONS.md** - Instruções detalhadas
- **INTEGRATION_GUIDE.md** - Como integrar com Dylib
- **README.md** - Referência completa

## 🎯 Próximos Passos

1. ✅ Compilar Tweak
2. ✅ Injetar no iPhone
3. ✅ Testar em Free Fire
4. 🔄 Ajustar injeção de eventos
5. 🔄 Adicionar mais perfis
6. 🔄 Distribuir

---

**Tempo estimado: 15 minutos** ⏱️

**Desenvolvido com ❤️ para iOS Jailbreak/TrollStore**
