import UIKit

class MainViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = UIColor(white: 0.1, alpha: 1.0)
        
        // Título
        let titleLabel = UILabel()
        titleLabel.text = "🎮 Nexus Mapper"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)
        
        // Descrição
        let descLabel = UILabel()
        descLabel.text = "Overlay de Mapeamento para Jogos\n\nO painel flutuante aparecerá quando você abrir um jogo.\n\nToque no botão 'N' para configurar sensibilidade, perfis e mais."
        descLabel.textColor = UIColor(white: 0.7, alpha: 1.0)
        descLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        descLabel.textAlignment = .center
        descLabel.numberOfLines = 0
        descLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(descLabel)
        
        // Status
        let statusLabel = UILabel()
        statusLabel.text = "✅ Tweak Ativo"
        statusLabel.textColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        statusLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        statusLabel.textAlignment = .center
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        
        // Botão de Teste
        let testButton = UIButton(type: .system)
        testButton.setTitle("Testar Painel", for: .normal)
        testButton.backgroundColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        testButton.setTitleColor(.white, for: .normal)
        testButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        testButton.layer.cornerRadius = 8
        testButton.translatesAutoresizingMaskIntoConstraints = false
        testButton.addTarget(self, action: #selector(testPanel), for: .touchUpInside)
        view.addSubview(testButton)
        
        // Constraints
        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            
            descLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            descLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 30),
            descLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            descLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.topAnchor.constraint(equalTo: descLabel.bottomAnchor, constant: 40),
            
            testButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            testButton.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 40),
            testButton.widthAnchor.constraint(equalToConstant: 200),
            testButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc private func testPanel() {
        OverlayMenuManager.shared.togglePanel()
    }
}
