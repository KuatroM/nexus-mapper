import UIKit

/// OverlayMenuManager - Gerencia a UIWindow global do overlay do Nexus Mapper
/// Responsável por criar, mostrar e controlar o botão flutuante e painel de configuração
class OverlayMenuManager {
    static let shared = OverlayMenuManager()
    
    private var overlayWindow: UIWindow?
    private var floatingButton: FloatingButtonView?
    private var configPanel: ConfigurationPanelView?
    
    private var isExpanded = false
    
    // MARK: - Configurações Persistentes
    var sensitivityX: Float = 1.0
    var sensitivityY: Float = 1.0
    var currentProfile: String = "Free Fire"
    var showButtonsOnScreen: Bool = true
    
    // MARK: - Inicialização
    func initialize() {
        createOverlayWindow()
        loadSettings()
        print("[NexusMapper] Overlay inicializado com sucesso")
    }
    
    // MARK: - Criar UIWindow Global
    private func createOverlayWindow() {
        // Criar UIWindow com windowLevel.alert + 100 para ficar acima de tudo
        overlayWindow = UIWindow(frame: UIScreen.main.bounds)
        overlayWindow?.windowLevel = UIWindow.Level.alert + 100
        overlayWindow?.backgroundColor = .clear
        overlayWindow?.isUserInteractionEnabled = true
        
        // Criar view controller raiz
        let rootVC = UIViewController()
        rootVC.view.backgroundColor = .clear
        overlayWindow?.rootViewController = rootVC
        
        // Mostrar a janela
        overlayWindow?.makeKeyAndVisible()
        
        // Criar botão flutuante
        createFloatingButton()
    }
    
    // MARK: - Criar Botão Flutuante
    private func createFloatingButton() {
        guard let window = overlayWindow else { return }
        
        floatingButton = FloatingButtonView(frame: CGRect(x: 20, y: 100, width: 60, height: 60))
        floatingButton?.delegate = self
        
        if let button = floatingButton {
            window.rootViewController?.view.addSubview(button)
        }
    }
    
    // MARK: - Mostrar/Ocultar Painel
    func togglePanel() {
        if isExpanded {
            hidePanel()
        } else {
            showPanel()
        }
    }
    
    private func showPanel() {
        guard let window = overlayWindow else { return }
        
        if configPanel == nil {
            configPanel = ConfigurationPanelView(frame: UIScreen.main.bounds)
            configPanel?.delegate = self
            configPanel?.updateValues(
                sensitivityX: sensitivityX,
                sensitivityY: sensitivityY,
                currentProfile: currentProfile,
                showButtons: showButtonsOnScreen
            )
        }
        
        if let panel = configPanel {
            window.rootViewController?.view.addSubview(panel)
            
            // Animar entrada
            panel.alpha = 0
            UIView.animate(withDuration: 0.3) {
                panel.alpha = 1.0
            }
        }
        
        floatingButton?.hide()
        isExpanded = true
    }
    
    private func hidePanel() {
        guard let panel = configPanel else { return }
        
        UIView.animate(withDuration: 0.3, animations: {
            panel.alpha = 0
        }) { _ in
            panel.removeFromSuperview()
        }
        
        floatingButton?.show()
        isExpanded = false
    }
    
    // MARK: - Persistência de Configurações
    private func loadSettings() {
        let defaults = UserDefaults.standard
        sensitivityX = defaults.float(forKey: "nexus_sensitivity_x") != 0 ? defaults.float(forKey: "nexus_sensitivity_x") : 1.0
        sensitivityY = defaults.float(forKey: "nexus_sensitivity_y") != 0 ? defaults.float(forKey: "nexus_sensitivity_y") : 1.0
        currentProfile = defaults.string(forKey: "nexus_profile") ?? "Free Fire"
        showButtonsOnScreen = defaults.bool(forKey: "nexus_show_buttons") != false
    }
    
    private func saveSettings() {
        let defaults = UserDefaults.standard
        defaults.set(sensitivityX, forKey: "nexus_sensitivity_x")
        defaults.set(sensitivityY, forKey: "nexus_sensitivity_y")
        defaults.set(currentProfile, forKey: "nexus_profile")
        defaults.set(showButtonsOnScreen, forKey: "nexus_show_buttons")
        defaults.synchronize()
        print("[NexusMapper] Configurações salvas")
    }
}

// MARK: - FloatingButtonView
class FloatingButtonView: UIView {
    weak var delegate: OverlayMenuManager?
    
    private let label = UILabel()
    private var lastLocation: CGPoint = .zero
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        // Fundo preto semi-transparente
        backgroundColor = UIColor(white: 0, alpha: 0.5)
        layer.cornerRadius = frame.width / 2
        clipsToBounds = true
        
        // Label "N"
        label.text = "N"
        label.textColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0) // Azul claro
        label.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        label.textAlignment = .center
        label.frame = bounds
        addSubview(label)
        
        // Gestos
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        addGestureRecognizer(tapGesture)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        addGestureRecognizer(panGesture)
        
        isUserInteractionEnabled = true
    }
    
    @objc private func handleTap() {
        delegate?.togglePanel()
    }
    
    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: superview)
        
        switch gesture.state {
        case .began:
            lastLocation = center
        case .changed:
            center = CGPoint(
                x: lastLocation.x + translation.x,
                y: lastLocation.y + translation.y
            )
        case .ended, .cancelled:
            // Manter dentro dos limites da tela
            var newCenter = center
            let radius = frame.width / 2
            
            if newCenter.x - radius < 0 {
                newCenter.x = radius
            }
            if newCenter.x + radius > UIScreen.main.bounds.width {
                newCenter.x = UIScreen.main.bounds.width - radius
            }
            if newCenter.y - radius < 0 {
                newCenter.y = radius
            }
            if newCenter.y + radius > UIScreen.main.bounds.height {
                newCenter.y = UIScreen.main.bounds.height - radius
            }
            
            UIView.animate(withDuration: 0.2) {
                self.center = newCenter
            }
        default:
            break
        }
    }
    
    func hide() {
        UIView.animate(withDuration: 0.2) {
            self.alpha = 0
            self.isUserInteractionEnabled = false
        }
    }
    
    func show() {
        UIView.animate(withDuration: 0.2) {
            self.alpha = 1.0
            self.isUserInteractionEnabled = true
        }
    }
}

// MARK: - ConfigurationPanelView
class ConfigurationPanelView: UIView {
    weak var delegate: OverlayMenuManager?
    
    private let containerView = UIView()
    private let titleLabel = UILabel()
    private let closeButton = UIButton()
    
    // Controles
    private let sensitivityXSlider = UISlider()
    private let sensitivityYSlider = UISlider()
    private let profileSegment = UISegmentedControl(items: ["Free Fire", "PUBG", "CoD", "Fortnite", "Standoff"])
    private let showButtonsSwitch = UISwitch()
    private let saveButton = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        // Fundo semi-transparente
        backgroundColor = UIColor(white: 0, alpha: 0.3)
        
        // Container principal
        containerView.backgroundColor = UIColor(white: 0.1, alpha: 0.95)
        containerView.layer.cornerRadius = 12
        containerView.clipsToBounds = true
        addSubview(containerView)
        
        // Calcular tamanho do container (80% da tela, centralizado)
        let width = UIScreen.main.bounds.width * 0.85
        let height = UIScreen.main.bounds.height * 0.7
        let x = (UIScreen.main.bounds.width - width) / 2
        let y = (UIScreen.main.bounds.height - height) / 2
        containerView.frame = CGRect(x: x, y: y, width: width, height: height)
        
        // Título
        titleLabel.text = "⚙️ Configurações"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        titleLabel.frame = CGRect(x: 16, y: 16, width: width - 60, height: 30)
        containerView.addSubview(titleLabel)
        
        // Botão Fechar (X)
        closeButton.setTitle("✕", for: .normal)
        closeButton.setTitleColor(UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0), for: .normal)
        closeButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        closeButton.frame = CGRect(x: width - 40, y: 16, width: 30, height: 30)
        closeButton.addTarget(self, action: #selector(handleClose), for: .touchUpInside)
        containerView.addSubview(closeButton)
        
        // ScrollView para conteúdo
        let scrollView = UIScrollView(frame: CGRect(x: 0, y: 60, width: width, height: height - 120))
        scrollView.showsVerticalScrollIndicator = false
        containerView.addSubview(scrollView)
        
        var yOffset: CGFloat = 16
        
        // MARK: - Sensibilidade X
        let labelX = UILabel(frame: CGRect(x: 16, y: yOffset, width: width - 32, height: 20))
        labelX.text = "Sensibilidade X: 1.0x"
        labelX.textColor = .white
        labelX.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        scrollView.addSubview(labelX)
        
        yOffset += 30
        sensitivityXSlider.frame = CGRect(x: 16, y: yOffset, width: width - 32, height: 30)
        sensitivityXSlider.minimumValue = 0.1
        sensitivityXSlider.maximumValue = 3.0
        sensitivityXSlider.value = 1.0
        sensitivityXSlider.minimumTrackTintColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        sensitivityXSlider.maximumTrackTintColor = UIColor(white: 0.3, alpha: 1.0)
        sensitivityXSlider.addTarget(self, action: #selector(sensitivityXChanged), for: .valueChanged)
        scrollView.addSubview(sensitivityXSlider)
        
        yOffset += 50
        
        // MARK: - Sensibilidade Y
        let labelY = UILabel(frame: CGRect(x: 16, y: yOffset, width: width - 32, height: 20))
        labelY.text = "Sensibilidade Y: 1.0x"
        labelY.textColor = .white
        labelY.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        scrollView.addSubview(labelY)
        
        yOffset += 30
        sensitivityYSlider.frame = CGRect(x: 16, y: yOffset, width: width - 32, height: 30)
        sensitivityYSlider.minimumValue = 0.1
        sensitivityYSlider.maximumValue = 3.0
        sensitivityYSlider.value = 1.0
        sensitivityYSlider.minimumTrackTintColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        sensitivityYSlider.maximumTrackTintColor = UIColor(white: 0.3, alpha: 1.0)
        sensitivityYSlider.addTarget(self, action: #selector(sensitivityYChanged), for: .valueChanged)
        scrollView.addSubview(sensitivityYSlider)
        
        yOffset += 50
        
        // MARK: - Perfis
        let labelProfile = UILabel(frame: CGRect(x: 16, y: yOffset, width: width - 32, height: 20))
        labelProfile.text = "Perfil"
        labelProfile.textColor = .white
        labelProfile.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        scrollView.addSubview(labelProfile)
        
        yOffset += 30
        profileSegment.frame = CGRect(x: 16, y: yOffset, width: width - 32, height: 32)
        profileSegment.selectedSegmentIndex = 0
        profileSegment.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)
        profileSegment.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.black], for: .selected)
        profileSegment.backgroundColor = UIColor(white: 0.2, alpha: 1.0)
        profileSegment.addTarget(self, action: #selector(profileChanged), for: .valueChanged)
        scrollView.addSubview(profileSegment)
        
        yOffset += 50
        
        // MARK: - Mostrar Botões
        let labelSwitch = UILabel(frame: CGRect(x: 16, y: yOffset, width: width - 80, height: 20))
        labelSwitch.text = "Mostrar Botões"
        labelSwitch.textColor = .white
        labelSwitch.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        scrollView.addSubview(labelSwitch)
        
        showButtonsSwitch.frame = CGRect(x: width - 60, y: yOffset - 5, width: 50, height: 30)
        showButtonsSwitch.isOn = true
        showButtonsSwitch.onTintColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        showButtonsSwitch.addTarget(self, action: #selector(switchChanged), for: .valueChanged)
        scrollView.addSubview(showButtonsSwitch)
        
        yOffset += 50
        
        // Definir tamanho do scrollView
        scrollView.contentSize = CGSize(width: width, height: yOffset + 20)
        
        // MARK: - Botão Salvar
        saveButton.setTitle("💾 Salvar e Fechar", for: .normal)
        saveButton.setTitleColor(.white, for: .normal)
        saveButton.backgroundColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
        saveButton.layer.cornerRadius = 8
        saveButton.frame = CGRect(x: 16, y: height - 50, width: width - 32, height: 40)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        saveButton.addTarget(self, action: #selector(handleSave), for: .touchUpInside)
        containerView.addSubview(saveButton)
        
        // Fechar ao tocar fora do container
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleBackgroundTap(_:)))
        addGestureRecognizer(tapGesture)
    }
    
    @objc private func sensitivityXChanged() {
        let value = sensitivityXSlider.value
        delegate?.sensitivityX = value
    }
    
    @objc private func sensitivityYChanged() {
        let value = sensitivityYSlider.value
        delegate?.sensitivityY = value
    }
    
    @objc private func profileChanged() {
        let profiles = ["Free Fire", "PUBG", "CoD", "Fortnite", "Standoff"]
        delegate?.currentProfile = profiles[profileSegment.selectedSegmentIndex]
    }
    
    @objc private func switchChanged() {
        delegate?.showButtonsOnScreen = showButtonsSwitch.isOn
    }
    
    @objc private func handleSave() {
        delegate?.saveSettings()
        delegate?.hidePanel()
    }
    
    @objc private func handleClose() {
        delegate?.hidePanel()
    }
    
    @objc private func handleBackgroundTap(_ gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: self)
        if !containerView.frame.contains(location) {
            delegate?.hidePanel()
        }
    }
    
    func updateValues(sensitivityX: Float, sensitivityY: Float, currentProfile: String, showButtons: Bool) {
        sensitivityXSlider.value = sensitivityX
        sensitivityYSlider.value = sensitivityY
        showButtonsSwitch.isOn = showButtons
        
        let profiles = ["Free Fire", "PUBG", "CoD", "Fortnite", "Standoff"]
        if let index = profiles.firstIndex(of: currentProfile) {
            profileSegment.selectedSegmentIndex = index
        }
    }
}
