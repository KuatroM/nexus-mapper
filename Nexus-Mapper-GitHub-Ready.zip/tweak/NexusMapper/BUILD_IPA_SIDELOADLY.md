# 📱 Compilar .ipa para Sideloadly - Nexus Mapper

## 🎯 Objetivo
Gerar um arquivo `.ipa` pronto para ser instalado via Sideloadly no iPhone.

## 📋 Pré-requisitos

- **Mac com Xcode 14+**
- **iOS 14+ SDK**
- **Sideloadly** instalado no Mac ([Download](https://sideloadly.io/))
- **iPhone com iOS 14+**

## 🚀 Passo 1: Preparar Projeto no Xcode

### 1.1 Criar Novo Projeto

1. Abra **Xcode**
2. File → New → Project
3. Selecione **App** (iOS)
4. Nome: `NexusMapper`
5. Organization Identifier: `com.seu-nome.nexusmapper`
6. Language: **Swift**
7. Clique em **Create**

### 1.2 Adicionar Arquivos

Copie estes arquivos para o projeto:

```
✅ OverlayMenuManager.swift
✅ TouchInjectionController.swift
✅ NexusMapperHook.swift
✅ AppDelegate.swift
✅ MainViewController.swift
✅ Info.plist
```

Arraste-os para o Xcode e certifique-se de que estão no target.

## 🔧 Passo 2: Configurar Build Settings

### 2.1 Seleção de Team

1. Selecione o projeto `NexusMapper`
2. Selecione o target `NexusMapper`
3. Signing & Capabilities
4. Team: Selecione sua Apple ID (ou crie um certificado de desenvolvimento)

### 2.2 Bundle Identifier

1. General
2. Bundle Identifier: `com.seu-nome.nexusmapper`

### 2.3 Deployment Target

1. Build Settings
2. Procure por `Minimum Deployment Target`
3. Selecione `iOS 14.0` ou superior

### 2.4 Architectures

1. Build Settings
2. Procure por `Architectures`
3. Selecione `arm64` (para iPhone real)

## 🔨 Passo 3: Compilar para Arquivo

### 3.1 Via Terminal (Recomendado)

```bash
# Definir variáveis
PROJECT_NAME="NexusMapper"
BUNDLE_ID="com.seu-nome.nexusmapper"
TEAM_ID="seu-team-id"

# Compilar para iOS
xcodebuild \
  -project "$PROJECT_NAME.xcodeproj" \
  -scheme "$PROJECT_NAME" \
  -configuration Release \
  -arch arm64 \
  -sdk iphoneos \
  -derivedDataPath build \
  -allowProvisioningUpdates

# Criar arquivo
xcodebuild \
  -exportArchive \
  -archivePath "build/Archives/$PROJECT_NAME.xcarchive" \
  -exportPath "build/Export" \
  -exportOptionsPlist ExportOptions.plist
```

### 3.2 Via Xcode UI

1. Product → Archive
2. Aguarde a compilação
3. Clique em "Distribute App"
4. Selecione "Custom" ou "Ad Hoc"
5. Selecione seu certificado
6. Clique em "Export"
7. Salve o arquivo `.ipa`

## 📦 Passo 4: Encontrar o .ipa

Após compilar:

```bash
# Via Terminal
find ~/Library/Developer/Xcode/Archives -name "*.ipa" -type f
```

Ou:
- Xcode → Window → Organizer
- Selecione o archive
- Clique em "Export"

## 📱 Passo 5: Instalar via Sideloadly

### 5.1 Abrir Sideloadly

1. Abra **Sideloadly** no Mac
2. Conecte o iPhone via USB
3. Selecione o iPhone na lista

### 5.2 Selecionar .ipa

1. Clique em "Select IPA"
2. Procure pelo arquivo `NexusMapper.ipa`
3. Selecione

### 5.3 Instalar

1. Clique em "Start"
2. Aguarde a instalação
3. Clique em "Trust" no iPhone (se solicitado)

### 5.4 Executar

1. Vá para Home Screen
2. Procure por "Nexus Mapper"
3. Toque para abrir

## ✅ Testar

1. Abra um jogo (Free Fire, PUBG, etc.)
2. Procure pelo botão **"N"** flutuante
3. Toque para abrir o painel
4. Ajuste sensibilidade, perfil, etc.

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| "Signing certificate not found" | Ir para Signing & Capabilities e selecionar team |
| "Provisioning profile not found" | Xcode → Preferences → Accounts → Download Profiles |
| "IPA não instala" | Verificar se o Bundle ID é único |
| "App não abre" | Verificar Console (Xcode → Devices and Simulators) |
| "Botão N não aparece" | Verificar se `initialize()` foi chamado em AppDelegate |

## 📚 Arquivos Necessários

```
NexusMapper/
├── OverlayMenuManager.swift      ✅ UIWindow + Painel
├── TouchInjectionController.swift ✅ Injeção de eventos
├── NexusMapperHook.swift         ✅ Ponto de entrada
├── AppDelegate.swift             ✅ Inicialização
├── MainViewController.swift       ✅ UI Principal
├── Info.plist                    ✅ Configuração
└── Assets.xcassets/              ✅ Ícones (opcional)
```

## 🎯 Próximos Passos

1. ✅ Compilar .ipa
2. ✅ Instalar via Sideloadly
3. ✅ Testar em Free Fire
4. 🔄 Ajustar injeção de eventos
5. 🔄 Distribuir para amigos

## 📝 Notas Importantes

- O .ipa é válido por 7 dias (com certificado de desenvolvimento)
- Para distribuir permanentemente, use TestFlight ou App Store
- Sideloadly requer que o iPhone esteja conectado via USB

---

**Tempo estimado: 30 minutos** ⏱️

**Desenvolvido com ❤️ para iOS Jailbreak/TrollStore**
