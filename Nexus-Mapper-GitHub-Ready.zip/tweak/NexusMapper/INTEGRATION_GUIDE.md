# 🎮 Nexus Mapper Tweak - Guia de Integração

## Visão Geral

O Tweak do Nexus Mapper é um módulo iOS em Swift que fornece um overlay in-game com interface de configuração. Ele deve ser injetado no processo do jogo via Dylib/Tweak.

## Arquitetura

```
NexusMapperHook.swift
├── OverlayMenuManager.swift
│   ├── FloatingButtonView (Botão "N" draggável)
│   └── ConfigurationPanelView (Painel Dark Mode)
├── TouchInjectionController.swift
└── [Dylib/Tweak Entry Point]
```

## Componentes

### 1. **OverlayMenuManager** ✅
- **Responsabilidade**: Gerenciar UIWindow global e coordenar UI
- **Funcionalidades**:
  - Criar UIWindow com `windowLevel = .alert + 100`
  - Gerenciar botão flutuante e painel
  - Persistir configurações em UserDefaults
  - Alternar entre estado minimizado e expandido

- **Interface Pública**:
```swift
OverlayMenuManager.shared.initialize()  // Inicializar
OverlayMenuManager.shared.togglePanel() // Mostrar/ocultar painel
OverlayMenuManager.shared.sensitivityX  // Ler/escrever sensibilidade
OverlayMenuManager.shared.currentProfile // Ler/escrever perfil
OverlayMenuManager.shared.saveSettings() // Salvar em UserDefaults
```

### 2. **TouchInjectionController** ✅
- **Responsabilidade**: Injetar eventos de toque no jogo
- **Funcionalidades**:
  - Injetar toques simples
  - Injetar movimentos de mouse com sensibilidade
  - Injetar joystick (ângulo + magnitude)
  - Injetar triggers (L2/R2)
  - Executar macros (sequências de ações)

- **Interface Pública**:
```swift
TouchInjectionController.shared.injectTap(at: CGPoint)
TouchInjectionController.shared.injectJoystick(angle:magnitude:sensitivity:)
TouchInjectionController.shared.injectTrigger(_:pressure:)
TouchInjectionController.shared.injectMacro(_:)
TouchInjectionController.shared.setEnabled(_:)
```

### 3. **NexusMapperHook** ✅
- **Responsabilidade**: Ponto de entrada para injeção
- **Funcionalidades**:
  - Inicializar Tweak
  - Fornecer acesso aos managers
  - Bridge para Objective-C

- **Interface Pública**:
```swift
NexusMapperHook.initialize()                    // Inicializar
NexusMapperHook.getOverlayManager()             // Obter manager
NexusMapperHook.getTouchController()            // Obter controller

// Bridge Objective-C
NexusMapperBridge.initializeNexusMapper()
NexusMapperBridge.injectTapAt(_:_:)
```

## Como Integrar com Dylib

### Passo 1: Compilar o Tweak
```bash
cd /home/ubuntu/nexus-mapper/tweak/NexusMapper
swiftc -emit-library -module-name NexusMapper \
  OverlayMenuManager.swift \
  TouchInjectionController.swift \
  NexusMapperHook.swift \
  -o libNexusMapper.dylib
```

### Passo 2: Injetar no Processo do Jogo

**Opção A: Via DYLD_INSERT_LIBRARIES (Simples)**
```bash
DYLD_INSERT_LIBRARIES=/path/to/libNexusMapper.dylib /path/to/game
```

**Opção B: Via Tweak (Recomendado para Jailbreak)**

Criar arquivo `Tweak.xm`:
```objectivec
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
  %orig;
  
  // Injetar Nexus Mapper
  NSString *tweakPath = @"/Library/Frameworks/NexusMapper.framework/NexusMapper";
  void *handle = dlopen([tweakPath UTF8String], RTLD_LAZY);
  
  if (handle) {
    typedef void (*InitFunc)(void);
    InitFunc initFunc = (InitFunc)dlsym(handle, "NexusMapperHook_initialize");
    if (initFunc) {
      initFunc();
    }
  }
}
%end
```

### Passo 3: Chamar Inicialização

**Em Swift:**
```swift
NexusMapperHook.initialize()
```

**Em Objective-C:**
```objc
[NexusMapperBridge initializeNexusMapper];
```

## Fluxo de Uso

1. **Usuário Abre o Jogo**
   - Dylib é injetado automaticamente
   - `NexusMapperHook.initialize()` é chamado

2. **Overlay Aparece**
   - Botão flutuante "N" aparece no canto da tela
   - UIWindow com windowLevel.alert + 100 fica acima do jogo

3. **Usuário Toca no Botão "N"**
   - Painel de configuração abre com animação
   - Mostra sliders de sensibilidade, perfis, etc.

4. **Usuário Configura**
   - Ajusta sensibilidade X/Y
   - Seleciona perfil (Free Fire, PUBG, etc.)
   - Ativa/desativa botões na tela
   - Clica "Salvar e Fechar"

5. **Configurações São Persistidas**
   - UserDefaults salva em `nexus_*` keys
   - Próxima vez que abrir, carrega automaticamente

6. **Eventos São Injetados**
   - Joystick → `TouchInjectionController.injectJoystick()`
   - Triggers → `TouchInjectionController.injectTrigger()`
   - Macros → `TouchInjectionController.injectMacro()`

## Configurações Persistidas

```swift
UserDefaults.standard.float(forKey: "nexus_sensitivity_x")    // 0.1 - 3.0
UserDefaults.standard.float(forKey: "nexus_sensitivity_y")    // 0.1 - 3.0
UserDefaults.standard.string(forKey: "nexus_profile")         // "Free Fire", "PUBG", etc
UserDefaults.standard.bool(forKey: "nexus_show_buttons")      // true/false
```

## Customização

### Mudar Cor do Botão Flutuante
Em `FloatingButtonView.setupUI()`:
```swift
label.textColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0) // Azul claro
```

### Mudar Perfis Disponíveis
Em `ConfigurationPanelView.setupUI()`:
```swift
let profileSegment = UISegmentedControl(items: ["Seu Jogo 1", "Seu Jogo 2", ...])
```

### Mudar Tamanho do Painel
Em `ConfigurationPanelView.setupUI()`:
```swift
let width = UIScreen.main.bounds.width * 0.85  // 85% da tela
let height = UIScreen.main.bounds.height * 0.7 // 70% da tela
```

## Troubleshooting

| Problema | Solução |
|----------|---------|
| Overlay não aparece | Verificar se `initialize()` foi chamado |
| Botão não é draggável | Verificar `isUserInteractionEnabled = true` |
| Painel não fecha | Verificar se `hidePanel()` está sendo chamado |
| Configurações não salvam | Verificar `UserDefaults.synchronize()` |
| Eventos não são injetados | Verificar se `TouchInjectionController.setEnabled(true)` |

## Próximos Passos

1. ✅ Compilar Tweak em Swift
2. ✅ Injetar via Dylib
3. 🔄 Testar em Free Fire (iOS)
4. 🔄 Ajustar injeção de eventos para o jogo específico
5. 🔄 Adicionar suporte a mais jogos
6. 🔄 Distribuir via TrollStore/Jailbreak

## Referências

- [UIWindow Documentation](https://developer.apple.com/documentation/uikit/uiwindow)
- [UIEvent Documentation](https://developer.apple.com/documentation/uikit/uievent)
- [DYLD Documentation](https://developer.apple.com/library/archive/documentation/DeveloperTools/Conceptual/DynamicLibraries/100-Articles/DynamicLibraryUsageGuide.html)
- [Theos Tweak Development](https://theos.dev/)
