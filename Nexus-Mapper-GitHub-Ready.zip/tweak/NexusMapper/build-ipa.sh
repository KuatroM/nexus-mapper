#!/bin/bash

# 🔨 Script de Compilação Automática para .ipa - Nexus Mapper
# Execute este script no Mac com Xcode instalado

set -e

echo "🚀 Nexus Mapper - Build IPA Script"
echo "===================================="

# Verificar se está no Mac
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "❌ Este script deve ser executado no Mac"
    exit 1
fi

# Verificar se Xcode está instalado
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ Xcode não está instalado"
    exit 1
fi

echo "✅ Xcode encontrado"

# Configurações
PROJECT_NAME="NexusMapper"
BUNDLE_ID="com.nexusmapper.app"
SCHEME="NexusMapper"
CONFIGURATION="Release"
DERIVED_DATA_PATH="build"
EXPORT_PATH="build/Export"
ARCHIVE_PATH="build/Archives/$PROJECT_NAME.xcarchive"

# Diretório do projeto
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "📁 Diretório do projeto: $PROJECT_DIR"

# Criar diretórios
mkdir -p "$PROJECT_DIR/$DERIVED_DATA_PATH"
mkdir -p "$PROJECT_DIR/$(dirname $ARCHIVE_PATH)"
mkdir -p "$PROJECT_DIR/$EXPORT_PATH"

# Passo 1: Limpar build anterior
echo ""
echo "🧹 Limpando build anterior..."
xcodebuild clean -project "$PROJECT_DIR/$PROJECT_NAME.xcodeproj" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -derivedDataPath "$PROJECT_DIR/$DERIVED_DATA_PATH" 2>&1 | grep -E "(error|warning)" || true

# Passo 2: Compilar
echo ""
echo "🔨 Compilando para iOS..."
xcodebuild build-for-testing \
    -project "$PROJECT_DIR/$PROJECT_NAME.xcodeproj" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -arch arm64 \
    -sdk iphoneos \
    -derivedDataPath "$PROJECT_DIR/$DERIVED_DATA_PATH" \
    -allowProvisioningUpdates 2>&1 | grep -E "(error|warning|Building)" || true

# Passo 3: Criar Archive
echo ""
echo "📦 Criando archive..."
xcodebuild archive \
    -project "$PROJECT_DIR/$PROJECT_NAME.xcodeproj" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -arch arm64 \
    -sdk iphoneos \
    -derivedDataPath "$PROJECT_DIR/$DERIVED_DATA_PATH" \
    -archivePath "$PROJECT_DIR/$ARCHIVE_PATH" \
    -allowProvisioningUpdates 2>&1 | grep -E "(error|warning|Archiving)" || true

if [ ! -d "$PROJECT_DIR/$ARCHIVE_PATH" ]; then
    echo "❌ Falha ao criar archive"
    exit 1
fi

echo "✅ Archive criado: $ARCHIVE_PATH"

# Passo 4: Exportar IPA
echo ""
echo "📤 Exportando IPA..."
xcodebuild -exportArchive \
    -archivePath "$PROJECT_DIR/$ARCHIVE_PATH" \
    -exportPath "$PROJECT_DIR/$EXPORT_PATH" \
    -exportOptionsPlist "$PROJECT_DIR/ExportOptions.plist" \
    -allowProvisioningUpdates 2>&1 | grep -E "(error|warning|Exporting)" || true

# Encontrar o IPA
IPA_FILE=$(find "$PROJECT_DIR/$EXPORT_PATH" -name "*.ipa" -type f | head -1)

if [ -z "$IPA_FILE" ]; then
    echo "❌ Falha ao exportar IPA"
    exit 1
fi

echo "✅ IPA exportado com sucesso!"
echo ""
echo "📊 Informações do IPA:"
file "$IPA_FILE"
ls -lh "$IPA_FILE"

echo ""
echo "🎉 Build completo!"
echo ""
echo "Próximos passos:"
echo "1. Abra Sideloadly"
echo "2. Conecte o iPhone"
echo "3. Selecione o arquivo IPA: $IPA_FILE"
echo "4. Clique em 'Start'"
echo "5. Abra um jogo e procure pelo botão 'N'"
echo ""
echo "📱 Arquivo: $IPA_FILE"
