#!/bin/bash

# 🔨 Script de Compilação Automática - Nexus Mapper Tweak
# Execute este script no Mac com Xcode instalado

set -e

echo "🚀 Nexus Mapper Tweak - Build Script"
echo "===================================="

# Verificar se está no Mac
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "❌ Este script deve ser executado no Mac"
    exit 1
fi

# Verificar se Xcode está instalado
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ Xcode não está instalado"
    exit 1
fi

echo "✅ Xcode encontrado"

# Diretório do projeto
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
OUTPUT_DIR="$PROJECT_DIR/output"

# Criar diretórios
mkdir -p "$BUILD_DIR"
mkdir -p "$OUTPUT_DIR"

echo "📁 Diretório do projeto: $PROJECT_DIR"

# Opção 1: Compilar como Framework
echo ""
echo "Compilando como Framework..."

# Criar projeto temporário
TEMP_PROJECT="$BUILD_DIR/NexusMapper.xcodeproj"

if [ ! -d "$TEMP_PROJECT" ]; then
    echo "Criando projeto Xcode..."
    
    # Criar estrutura do projeto
    mkdir -p "$BUILD_DIR/NexusMapper.xcodeproj"
    
    # Copiar arquivos Swift
    cp "$PROJECT_DIR/OverlayMenuManager.swift" "$BUILD_DIR/"
    cp "$PROJECT_DIR/TouchInjectionController.swift" "$BUILD_DIR/"
    cp "$PROJECT_DIR/NexusMapperHook.swift" "$BUILD_DIR/"
fi

# Compilar para iOS (arm64)
echo "🔨 Compilando para iOS arm64..."
xcodebuild \
    -project "$TEMP_PROJECT" \
    -scheme NexusMapper \
    -configuration Release \
    -arch arm64 \
    -sdk iphoneos \
    -derivedDataPath "$BUILD_DIR/DerivedData" \
    2>&1 | grep -E "(error|warning|Building|Compiling)" || true

# Encontrar o dylib compilado
DYLIB_PATH=$(find "$BUILD_DIR/DerivedData" -name "libNexusMapper.dylib" 2>/dev/null | head -1)

if [ -z "$DYLIB_PATH" ]; then
    echo "❌ Falha ao compilar. Dylib não encontrado."
    exit 1
fi

echo "✅ Compilação bem-sucedida!"
echo "📦 Dylib: $DYLIB_PATH"

# Copiar para output
cp "$DYLIB_PATH" "$OUTPUT_DIR/libNexusMapper.dylib"
echo "✅ Dylib copiado para: $OUTPUT_DIR/libNexusMapper.dylib"

# Informações do dylib
echo ""
echo "📊 Informações do Dylib:"
file "$OUTPUT_DIR/libNexusMapper.dylib"
ls -lh "$OUTPUT_DIR/libNexusMapper.dylib"

echo ""
echo "🎉 Build completo!"
echo ""
echo "Próximos passos:"
echo "1. Copie o dylib para seu iPhone"
echo "2. Use Theos ou TrollStore para injetar"
echo "3. Abra um jogo e procure pelo botão 'N'"
echo ""
echo "📁 Arquivo: $OUTPUT_DIR/libNexusMapper.dylib"
