import UIKit

/// NexusMapperHook - Ponto de entrada para injeção no processo do jogo
/// Este arquivo deve ser chamado quando o Dylib é injetado no jogo
public class NexusMapperHook {
    public static func initialize() {
        DispatchQueue.main.async {
            print("[NexusMapper] 🚀 Inicializando Nexus Mapper Tweak...")
            
            // Inicializar o gerenciador de overlay
            OverlayMenuManager.shared.initialize()
            
            // Inicializar o controlador de injeção de eventos
            TouchInjectionController.shared.setEnabled(true)
            
            print("[NexusMapper] ✅ Tweak inicializado com sucesso!")
        }
    }
    
    public static func getOverlayManager() -> OverlayMenuManager {
        return OverlayMenuManager.shared
    }
    
    public static func getTouchController() -> TouchInjectionController {
        return TouchInjectionController.shared
    }
}

/// Extensão para facilitar integração com Objective-C
@objc public class NexusMapperBridge: NSObject {
    @objc public static func initializeNexusMapper() {
        NexusMapperHook.initialize()
    }
    
    @objc public static func getOverlayManager() -> OverlayMenuManager {
        return NexusMapperHook.getOverlayManager()
    }
    
    @objc public static func getTouchController() -> TouchInjectionController {
        return NexusMapperHook.getTouchController()
    }
    
    @objc public static func injectTapAt(_ x: CGFloat, _ y: CGFloat) {
        let position = CGPoint(x: x, y: y)
        TouchInjectionController.shared.injectTap(at: position)
    }
    
    @objc public static func injectJoystickWithAngle(_ angle: CGFloat, magnitude: CGFloat, sensitivity: Float) {
        TouchInjectionController.shared.injectJoystick(angle: angle, magnitude: magnitude, sensitivity: sensitivity)
    }
}
