# 🔨 Instruções de Compilação - Nexus Mapper Tweak

## ⚠️ IMPORTANTE

O Tweak do Nexus Mapper **DEVE ser compilado no Xcode no Mac**, pois usa UIKit (framework iOS).

Não é possível compilar no Linux porque UIKit não está disponível.

## 📋 Pré-requisitos

- **Mac com Xcode 14+** instalado
- **iOS 14+** SDK
- **CocoaPods** (opcional, para dependências)

## 🚀 Passo 1: Abrir no Xcode

### Opção A: Criar Projeto Framework (Recomendado)

1. Abra o Xcode
2. File → New → Project
3. Selecione "Framework" (iOS)
4. Nome: `NexusMapper`
5. Language: `Swift`
6. Targets: `NexusMapper` (iOS)

### Opção B: Criar Projeto Tweak (Theos)

Se você tem Theos instalado:

```bash
theos new:tweak NexusMapper
cd $THEOS/projects/NexusMapper
```

## 📂 Passo 2: Copiar Arquivos

Copie os 3 arquivos Swift para o projeto:

```
NexusMapper/
├── OverlayMenuManager.swift
├── TouchInjectionController.swift
└── NexusMapperHook.swift
```

## 🔧 Passo 3: Configurar Build Settings

No Xcode:

1. Selecione o target `NexusMapper`
2. Build Settings
3. Procure por:
   - **Mach-O Type**: `Dynamic Library`
   - **Product Name**: `libNexusMapper`
   - **Architectures**: `arm64` (para iPhone real)
   - **Minimum Deployment Target**: `14.0` ou superior

## 🛠️ Passo 4: Compilar

```bash
# Via terminal
xcodebuild -scheme NexusMapper -configuration Release -arch arm64

# Ou via Xcode UI
Product → Build (Cmd + B)
```

## 📦 Passo 5: Encontrar o Dylib

Após compilar, o dylib estará em:

```
build/Release-iphoneos/libNexusMapper.dylib
```

Ou via Xcode:
```
Product → Show Build Folder in Finder
```

## 📱 Passo 6: Instalar no iPhone

### Opção A: Via Theos (Jailbreak)

```bash
make package
make install THEOS_DEVICE_IP=seu.iphone.ip
```

### Opção B: Via TrollStore

1. Copie `libNexusMapper.dylib` para o iPhone
2. Use TrollStore para injetar em um app
3. Ou use um loader como `inject`

### Opção C: Via Xcode (Debugging)

1. Conecte o iPhone
2. Xcode → Product → Run
3. Selecione o app alvo (Free Fire, PUBG, etc.)

## ✅ Verificar Instalação

No iPhone, abra um jogo e procure pelo botão "N" flutuante no canto da tela.

Se não aparecer:
- Verificar Console (Xcode → Window → Devices and Simulators)
- Procurar por logs: `[NexusMapper]`

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| "No such module 'UIKit'" | Certifique-se de compilar no Xcode, não no terminal |
| Dylib não funciona | Verificar se está sendo injetado corretamente |
| Botão não aparece | Verificar se `initialize()` foi chamado |
| Erro de assinatura | Usar certificado de desenvolvimento válido |

## 📚 Referências

- [Xcode Documentation](https://developer.apple.com/xcode/)
- [Theos Documentation](https://theos.dev/)
- [TrollStore](https://github.com/34306/TrollStore)
- [UIKit Documentation](https://developer.apple.com/documentation/uikit)

## 🎯 Próximos Passos

1. ✅ Compilar no Xcode
2. ✅ Instalar no iPhone via Theos/TrollStore
3. ✅ Testar em Free Fire
4. ✅ Ajustar injeção de eventos
5. ✅ Distribuir

---

**Desenvolvido com ❤️ para iOS Jailbreak/TrollStore**
