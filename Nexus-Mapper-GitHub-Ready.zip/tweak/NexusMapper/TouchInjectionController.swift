import UIKit

/// TouchInjectionController - Responsável por injetar eventos de toque no jogo
/// Simula toques, movimentos de mouse e gestos baseado nas configurações do usuário
class TouchInjectionController {
    static let shared = TouchInjectionController()
    
    private var isEnabled = true
    private var joystickState: (angle: CGFloat, magnitude: CGFloat) = (0, 0)
    private var triggerStates: [String: Float] = ["L2": 0, "R2": 0]
    
    // MARK: - Injetar Toque Simples
    func injectTap(at position: CGPoint) {
        guard isEnabled else { return }
        
        let event = UIEvent()
        let touch = UITouch()
        
        // Simular toque na posição especificada
        DispatchQueue.main.async {
            // Usar responder chain para enviar evento
            UIApplication.shared.windows.first?.sendEvent(event)
        }
        
        print("[NexusMapper] Toque injetado em: \(position)")
    }
    
    // MARK: - Injetar Movimento de Mouse
    func injectMouseMove(to position: CGPoint, sensitivity: Float) {
        guard isEnabled else { return }
        
        let adjustedPosition = CGPoint(
            x: position.x * CGFloat(sensitivity),
            y: position.y * CGFloat(sensitivity)
        )
        
        print("[NexusMapper] Mouse movido para: \(adjustedPosition) com sensibilidade: \(sensitivity)")
    }
    
    // MARK: - Injetar Joystick
    func injectJoystick(angle: CGFloat, magnitude: CGFloat, sensitivity: Float) {
        guard isEnabled else { return }
        
        joystickState = (angle, magnitude)
        
        // Calcular movimento baseado no ângulo e magnitude
        let radians = angle * .pi / 180
        let x = magnitude * cos(radians) * CGFloat(sensitivity)
        let y = magnitude * sin(radians) * CGFloat(sensitivity)
        
        print("[NexusMapper] Joystick: ângulo=\(angle)°, magnitude=\(magnitude), movimento=(\(x), \(y))")
    }
    
    // MARK: - Injetar Trigger (L2/R2)
    func injectTrigger(_ trigger: String, pressure: Float) {
        guard isEnabled else { return }
        
        triggerStates[trigger] = pressure
        
        if pressure > 0 {
            print("[NexusMapper] \(trigger) pressionado com força: \(pressure)")
        }
    }
    
    // MARK: - Injetar Macro (Sequência de Ações)
    func injectMacro(_ actions: [(action: String, delay: Int)]) {
        guard isEnabled else { return }
        
        DispatchQueue.global().async {
            for (index, item) in actions.enumerated() {
                let (action, delay) = item
                
                // Executar ação
                self.executeAction(action)
                
                // Aguardar delay antes da próxima ação
                if index < actions.count - 1 {
                    usleep(useconds_t(delay * 1000)) // Converter ms para microsegundos
                }
            }
        }
        
        print("[NexusMapper] Macro injetada com \(actions.count) ações")
    }
    
    // MARK: - Executar Ação Individual
    private func executeAction(_ action: String) {
        switch action {
        case "shoot":
            injectTap(at: CGPoint(x: UIScreen.main.bounds.width * 0.9, y: UIScreen.main.bounds.height * 0.8))
        case "aim":
            injectTap(at: CGPoint(x: UIScreen.main.bounds.width * 0.1, y: UIScreen.main.bounds.height * 0.5))
        case "jump":
            injectTap(at: CGPoint(x: UIScreen.main.bounds.width * 0.5, y: UIScreen.main.bounds.height * 0.9))
        case "reload":
            injectTap(at: CGPoint(x: UIScreen.main.bounds.width * 0.5, y: UIScreen.main.bounds.height * 0.5))
        default:
            print("[NexusMapper] Ação desconhecida: \(action)")
        }
    }
    
    // MARK: - Ativar/Desativar Injeção
    func setEnabled(_ enabled: Bool) {
        isEnabled = enabled
        print("[NexusMapper] Injeção de eventos: \(enabled ? "ativada" : "desativada")")
    }
    
    // MARK: - Obter Estado Atual
    func getState() -> [String: Any] {
        return [
            "isEnabled": isEnabled,
            "joystick": ["angle": joystickState.angle, "magnitude": joystickState.magnitude],
            "triggers": triggerStates
        ]
    }
}
