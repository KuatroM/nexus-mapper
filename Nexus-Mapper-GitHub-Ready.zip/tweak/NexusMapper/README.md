# 🎮 Nexus Mapper Tweak - Overlay In-Game para iOS

Tweak iOS em Swift que fornece um overlay flutuante com interface de configuração para jogos mobile. Replicando a funcionalidade do GG Mouse Pro com design minimalista e flat.

## 🎯 Características

✅ **Overlay Flutuante**
- UIWindow com `windowLevel = .alert + 100` (sempre no topo)
- Botão "N" circular, draggável, semi-transparente
- Design minimalista e flat (sem neon, sem imagens pesadas)

✅ **Painel de Configuração**
- Dark mode (fundo preto/cinza escuro)
- Sliders de sensibilidade X/Y (0.1 - 3.0)
- UISegmentedControl para perfis (Free Fire, PUBG, CoD, Fortnite, Standoff)
- UISwitch para mostrar/ocultar botões
- Botão "Salvar e Fechar"

✅ **Injeção de Eventos**
- Injetar toques simples
- Injetar movimentos de mouse com sensibilidade
- Injetar joystick (ângulo + magnitude)
- Injetar triggers (L2/R2)
- Executar macros (sequências de ações)

✅ **Persistência**
- Salvar configurações em UserDefaults
- Carregar automaticamente ao iniciar

## 📁 Estrutura de Arquivos

```
tweak/NexusMapper/
├── OverlayMenuManager.swift         # UIWindow + FloatingButton + ConfigPanel
├── TouchInjectionController.swift   # Injeção de eventos
├── NexusMapperHook.swift           # Ponto de entrada + Bridge Objective-C
├── INTEGRATION_GUIDE.md            # Guia de integração com Dylib
└── README.md                       # Este arquivo
```

## 🚀 Como Usar

### 1. Compilar o Tweak

```bash
cd /home/ubuntu/nexus-mapper/tweak/NexusMapper

# Compilar em dylib
swiftc -emit-library -module-name NexusMapper \
  OverlayMenuManager.swift \
  TouchInjectionController.swift \
  NexusMapperHook.swift \
  -o libNexusMapper.dylib
```

### 2. Injetar no Jogo

**Via DYLD_INSERT_LIBRARIES:**
```bash
DYLD_INSERT_LIBRARIES=/path/to/libNexusMapper.dylib /path/to/game
```

**Via Theos (Jailbreak):**
```bash
theos new:tweak NexusMapper
# Copiar arquivos Swift para o projeto
make package
```

### 3. Inicializar no Código

**Swift:**
```swift
import NexusMapper

NexusMapperHook.initialize()
```

**Objective-C:**
```objc
#import <NexusMapper/NexusMapperBridge.h>

[NexusMapperBridge initializeNexusMapper];
```

## 🎮 Fluxo de Uso

1. Usuário abre o jogo
2. Tweak é injetado automaticamente
3. Botão "N" aparece no canto da tela
4. Usuário toca no botão → Painel abre
5. Usuário configura sensibilidade, perfil, etc.
6. Usuário clica "Salvar e Fechar"
7. Configurações são persistidas
8. Eventos são injetados durante o jogo

## 🎨 Design

### Botão Flutuante
- Tamanho: 60x60 pt
- Forma: Circular
- Fundo: Preto com alpha 0.5
- Texto: "N" em azul claro (#40CCFF)
- Interação: Tap para abrir painel, drag para mover

### Painel de Configuração
- Tamanho: 85% x 70% da tela, centralizado
- Fundo: Cinza escuro (UIColor(white: 0.1, alpha: 0.95))
- Bordas: Levemente arredondadas (cornerRadius: 12)
- Texto: Branco ou cinza claro
- Controles: Sliders, UISegmentedControl, UISwitch

## 📊 Configurações Persistidas

```
nexus_sensitivity_x     (Float)  - Sensibilidade eixo X (0.1-3.0)
nexus_sensitivity_y     (Float)  - Sensibilidade eixo Y (0.1-3.0)
nexus_profile          (String)  - Perfil selecionado
nexus_show_buttons     (Bool)    - Mostrar botões na tela
```

## 🔧 Customização

### Mudar Cor do Botão
Em `FloatingButtonView.setupUI()`:
```swift
label.textColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
```

### Adicionar Novo Perfil
Em `ConfigurationPanelView.setupUI()`:
```swift
let profileSegment = UISegmentedControl(items: ["Free Fire", "PUBG", "CoD", "Fortnite", "Standoff", "Seu Jogo"])
```

### Ajustar Tamanho do Painel
Em `ConfigurationPanelView.setupUI()`:
```swift
let width = UIScreen.main.bounds.width * 0.85
let height = UIScreen.main.bounds.height * 0.7
```

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| Overlay não aparece | Verificar se `initialize()` foi chamado no main thread |
| Botão não é draggável | Verificar `isUserInteractionEnabled = true` |
| Painel não fecha | Verificar se `hidePanel()` está sendo chamado |
| Configurações não salvam | Verificar `UserDefaults.synchronize()` |
| Eventos não são injetados | Verificar `TouchInjectionController.setEnabled(true)` |
| Erro de compilação Swift | Verificar versão do Swift (5.0+) |

## 📚 Referências

- [UIWindow Documentation](https://developer.apple.com/documentation/uikit/uiwindow)
- [UIEvent Documentation](https://developer.apple.com/documentation/uikit/uievent)
- [Theos Documentation](https://theos.dev/)
- [GG Mouse Pro](https://play.google.com/store/apps/details?id=com.ggmousepro.app)

## 📝 Licença

Nexus Mapper © 2026 - Todos os direitos reservados

## 🤝 Contribuições

Para contribuir, envie um pull request ou abra uma issue.

---

**Desenvolvido com ❤️ para iOS Jailbreak/TrollStore**
