# 🚀 GitHub Actions - Compilar .ipa Automaticamente

## 🎯 Objetivo
Usar GitHub Actions para compilar o .ipa no Mac da nuvem (grátis!) sem precisar de Mac.

## 📋 Pré-requisitos

- ✅ Conta GitHub (grátis)
- ✅ Este repositório
- ✅ Sideloadly instalado no PC/Mac

## 🚀 Passo 1: Criar Repositório GitHub

### 1.1 Criar Novo Repositório

1. Vá para [github.com/new](https://github.com/new)
2. Nome: `nexus-mapper`
3. Descrição: `Nexus Mapper - Overlay para Jogos iOS`
4. Selecione "Public" (para usar GitHub Actions grátis)
5. Clique em "Create repository"

### 1.2 Clonar Repositório

```bash
git clone https://github.com/seu-usuario/nexus-mapper.git
cd nexus-mapper
```

## 📁 Passo 2: Adicionar Arquivos

### 2.1 Copiar Estrutura

Copie todos os arquivos do projeto para o repositório:

```
nexus-mapper/
├── .github/
│   └── workflows/
│       └── build-ipa.yml          ✅ (já criado)
├── tweak/
│   └── NexusMapper/
│       ├── OverlayMenuManager.swift
│       ├── TouchInjectionController.swift
│       ├── NexusMapperHook.swift
│       ├── AppDelegate.swift
│       ├── MainViewController.swift
│       ├── Info.plist
│       ├── ExportOptions.plist
│       └── build-ipa.sh
└── README.md
```

### 2.2 Fazer Push

```bash
git add .
git commit -m "🚀 Initial commit - Nexus Mapper Tweak"
git push origin main
```

## ⚡ Passo 3: GitHub Actions Compila Automaticamente

### 3.1 Verificar Workflow

1. Vá para seu repositório no GitHub
2. Clique em "Actions"
3. Você verá o workflow "🔨 Build IPA for Sideloadly" rodando
4. Aguarde a compilação (5-10 minutos)

### 3.2 Acompanhar Compilação

- Verde ✅ = Sucesso
- Vermelho ❌ = Erro
- Amarelo ⏳ = Compilando

## 📥 Passo 4: Baixar .ipa

### 4.1 Via Releases

1. Vá para "Releases" no seu repositório
2. Procure pela release mais recente
3. Baixe o arquivo `NexusMapper.ipa`

### 4.2 Via Artifacts

1. Vá para "Actions"
2. Clique no workflow que compilou
3. Clique em "Artifacts"
4. Baixe `NexusMapper-IPA`

## 📱 Passo 5: Instalar com Sideloadly

1. **Baixe o .ipa** (veja acima)
2. **Abra Sideloadly** no seu PC/Mac
3. **Conecte o iPhone** via USB
4. **Select IPA** → Escolha `NexusMapper.ipa`
5. **Start** → Aguarde 2-3 minutos
6. **Pronto!** ✅

## ✅ Testar

1. Abra o app "Nexus Mapper" no iPhone
2. Clique em "Testar Painel"
3. Abra Free Fire ou outro jogo
4. Procure pelo botão "N" flutuante
5. Toque para abrir o painel! 🎮

## 🔄 Fazer Alterações

Se quiser fazer mudanças:

1. **Edite os arquivos** localmente
2. **Faça commit e push**:
   ```bash
   git add .
   git commit -m "🔧 Descrição da mudança"
   git push origin main
   ```
3. **GitHub Actions compila automaticamente**
4. **Baixe o novo .ipa**

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| Workflow não roda | Verificar se `.github/workflows/build-ipa.yml` está no repositório |
| Build falha | Verificar logs no GitHub Actions |
| IPA não instala | Tentar novamente com Sideloadly |
| Botão "N" não aparece | Abrir o app Nexus Mapper primeiro |

## 📊 Limites

- **GitHub Actions**: 2000 minutos/mês grátis (mais que suficiente)
- **Repositório**: Sem limite de tamanho
- **Releases**: Sem limite de downloads

## 🎯 Próximos Passos

1. ✅ Criar repositório GitHub
2. ✅ Fazer push do código
3. ✅ Aguardar compilação
4. ✅ Baixar .ipa
5. ✅ Instalar com Sideloadly
6. ✅ Testar em Free Fire

## 📚 Referências

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Sideloadly Website](https://sideloadly.io/)
- [Xcode Cloud](https://developer.apple.com/xcode-cloud/)

---

**Tempo total: 20 minutos** ⏱️

**Desenvolvido com ❤️ para iOS**
