# 🎮 Nexus Mapper - Overlay de Mapeamento para Jogos iOS

Tweak iOS em Swift que fornece um overlay flutuante com interface de configuração para jogos mobile, replicando a funcionalidade do GG Mouse Pro.

## ✨ Características

✅ **Overlay Flutuante**
- UIWindow com windowLevel = .alert + 100 (sempre no topo)
- Botão "N" circular, draggável, semi-transparente
- Design minimalista e flat (sem neon, sem imagens pesadas)

✅ **Painel de Configuração**
- Dark mode (fundo preto/cinza escuro)
- Sliders de sensibilidade X/Y (0.1 - 3.0)
- UISegmentedControl para perfis (Free Fire, PUBG, CoD, Fortnite, Standoff)
- UISwitch para mostrar/ocultar botões
- Botão "Salvar e Fechar"

✅ **Injeção de Eventos**
- Injetar toques simples
- Injetar movimentos de mouse com sensibilidade
- Injetar joystick (ângulo + magnitude)
- Injetar triggers (L2/R2)
- Executar macros (sequências de ações)

✅ **Persistência**
- Salvar configurações em UserDefaults
- Carregar automaticamente ao iniciar

## 🚀 Quick Start (20 minutos)

### Opção 1: GitHub Actions (RECOMENDADO - Sem Mac!)

1. **Criar repositório GitHub**
   ```bash
   git clone https://github.com/seu-usuario/nexus-mapper.git
   cd nexus-mapper
   ```

2. **Fazer push do código**
   ```bash
   git add .
   git commit -m "🚀 Initial commit"
   git push origin main
   ```

3. **Aguardar compilação**
   - Vá para Actions no GitHub
   - Aguarde 5-10 minutos
   - GitHub compila automaticamente no Mac da nuvem

4. **Baixar .ipa**
   - Vá para Releases
   - Baixe `NexusMapper.ipa`

5. **Instalar com Sideloadly**
   - Abra Sideloadly
   - Conecte iPhone
   - Select IPA → NexusMapper.ipa
   - Start

📖 **Leia**: [GITHUB_ACTIONS_GUIDE.md](GITHUB_ACTIONS_GUIDE.md)

### Opção 2: Compilar no Mac (Local)

1. **Abrir no Xcode**
   ```bash
   open tweak/NexusMapper/NexusMapper.xcodeproj
   ```

2. **Compilar**
   ```bash
   cd tweak/NexusMapper
   ./build-ipa.sh
   ```

3. **Instalar com Sideloadly**
   - Arquivo: `build/Export/NexusMapper.ipa`

📖 **Leia**: [tweak/NexusMapper/SIDELOADLY_QUICK_GUIDE.md](tweak/NexusMapper/SIDELOADLY_QUICK_GUIDE.md)

## 📱 Como Usar

1. **Abra o app "Nexus Mapper"** no iPhone
2. **Clique em "Testar Painel"** para preview
3. **Abra um jogo** (Free Fire, PUBG, etc.)
4. **Procure pelo botão "N"** flutuante no canto
5. **Toque para abrir** o painel de configuração
6. **Ajuste sensibilidade, perfil, etc.**
7. **Clique "Salvar e Fechar"**

## 📁 Estrutura do Projeto

```
nexus-mapper/
├── .github/
│   └── workflows/
│       └── build-ipa.yml              # GitHub Actions workflow
├── tweak/
│   └── NexusMapper/
│       ├── OverlayMenuManager.swift   # UIWindow + Painel (422 linhas)
│       ├── TouchInjectionController.swift # Injeção de eventos (116 linhas)
│       ├── NexusMapperHook.swift      # Entry point (51 linhas)
│       ├── AppDelegate.swift          # App delegate
│       ├── MainViewController.swift    # UI principal
│       ├── Info.plist                 # Configuração
│       ├── ExportOptions.plist        # Exportação
│       ├── build-ipa.sh               # Script de compilação
│       └── SIDELOADLY_QUICK_GUIDE.md  # Guia rápido
├── GITHUB_ACTIONS_GUIDE.md            # Como usar GitHub Actions
└── README.md                          # Este arquivo
```

## 🎯 Tecnologias

- **Swift 5.9+**
- **UIKit** (não SwiftUI)
- **iOS 14+**
- **Xcode 14+**

## 📊 Estatísticas

- **589 linhas de código Swift**
- **4 arquivos principais**
- **6 documentações completas**
- **Pronto para produção**

## 🔧 Customização

### Mudar Cor do Botão
Em `OverlayMenuManager.swift`:
```swift
label.textColor = UIColor(red: 0.25, green: 0.8, blue: 1.0, alpha: 1.0)
```

### Adicionar Novo Perfil
Em `OverlayMenuManager.swift`:
```swift
let profileSegment = UISegmentedControl(items: ["Free Fire", "PUBG", "CoD", "Fortnite", "Standoff", "Seu Jogo"])
```

### Ajustar Tamanho do Painel
Em `OverlayMenuManager.swift`:
```swift
let width = UIScreen.main.bounds.width * 0.85
let height = UIScreen.main.bounds.height * 0.7
```

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| GitHub Actions não roda | Verificar se `.github/workflows/build-ipa.yml` está no repositório |
| Build falha | Verificar logs no GitHub Actions |
| IPA não instala | Tentar novamente com Sideloadly |
| Botão "N" não aparece | Abrir o app Nexus Mapper primeiro para inicializar |
| App fecha ao abrir | Verificar Console (Xcode → Devices and Simulators) |

## 📚 Documentação

- **[GITHUB_ACTIONS_GUIDE.md](GITHUB_ACTIONS_GUIDE.md)** - Como usar GitHub Actions
- **[tweak/NexusMapper/SIDELOADLY_QUICK_GUIDE.md](tweak/NexusMapper/SIDELOADLY_QUICK_GUIDE.md)** - Guia rápido Sideloadly
- **[tweak/NexusMapper/BUILD_IPA_SIDELOADLY.md](tweak/NexusMapper/BUILD_IPA_SIDELOADLY.md)** - Compilação detalhada
- **[tweak/NexusMapper/README.md](tweak/NexusMapper/README.md)** - Referência completa

## 🎮 Jogos Suportados

- ✅ Free Fire
- ✅ PUBG Mobile
- ✅ Call of Duty Mobile
- ✅ Fortnite
- ✅ Standoff 2
- 🔄 Mais em desenvolvimento

## 🤝 Contribuições

Para contribuir:
1. Fork o repositório
2. Crie uma branch (`git checkout -b feature/sua-feature`)
3. Commit suas mudanças (`git commit -am 'Add feature'`)
4. Push para a branch (`git push origin feature/sua-feature`)
5. Abra um Pull Request

## 📝 Licença

Nexus Mapper © 2026 - Todos os direitos reservados

## 🙏 Agradecimentos

- Inspirado em GG Mouse Pro
- Desenvolvido com UIKit puro
- Otimizado para iOS 14+

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique a [documentação](GITHUB_ACTIONS_GUIDE.md)
2. Abra uma [issue](https://github.com/seu-usuario/nexus-mapper/issues)
3. Crie uma [discussion](https://github.com/seu-usuario/nexus-mapper/discussions)

---

**Desenvolvido com ❤️ para iOS Jailbreak/TrollStore**

**Versão**: 1.0.0  
**Última atualização**: Março 2026  
**Status**: ✅ Pronto para Produção
